document.addEventListener('DOMContentLoaded', function() {
  console.log('Project v4 vippro is ready!');
});